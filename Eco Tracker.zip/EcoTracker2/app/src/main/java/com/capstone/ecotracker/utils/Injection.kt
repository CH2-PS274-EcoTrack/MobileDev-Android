package com.capstone.ecotracker.utils

import android.content.Context
import com.capstone.ecotracker.data.Repository
import com.capstone.ecotracker.data.localDatabase.ItemDatabase
import com.capstone.ecotracker.data.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): Repository {
        val apiService = ApiConfig.getApiService()
        val database = ItemDatabase.getInstance(context)
        val dao = database.dao()
        return Repository.getInstance(apiService, dao)
    }
}