package com.capstone.ecotracker.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.capstone.ecotracker.data.localDatabase.Item
import com.capstone.ecotracker.data.localDatabase.ItemDao
import com.capstone.ecotracker.data.response.ForecastResponse
import com.capstone.ecotracker.data.response.ImageResponse
import com.capstone.ecotracker.data.response.UploadImageResponse
import com.capstone.ecotracker.data.response.UploadInputResponse
import com.capstone.ecotracker.data.retrofit.ApiService
import kotlinx.coroutines.Dispatchers
import okhttp3.MultipartBody

class Repository(
    private val apiService: ApiService,
    private val dao: ItemDao
) {
    fun uploadImage(
        image: MultipartBody.Part
    ): LiveData<Result<UploadImageResponse>> =
        liveData(Dispatchers.IO) {
            apiService.uploadImage(image)
        }

    fun uploadUserInput(
        cylinder: Double,
        engineSize: Double,
        fuelConsumption: Double
    ): LiveData<Result<UploadInputResponse>> =
        liveData(Dispatchers.IO) {
            apiService.uploadUserInput(cylinder, engineSize, fuelConsumption)
        }

    fun getImageResult(): LiveData<ImageResponse>
    = liveData(Dispatchers.IO) {
        apiService.getImage() }

    fun getForecastResult(): LiveData<ForecastResponse>
            = liveData(Dispatchers.IO) {
        apiService.getForecast() }

    fun getItemById(itemId: Int): LiveData<Item> {
        return dao.getItemById(itemId)
    }

    fun getAllItem(): LiveData<List<Item>> {
        return dao.getAllItem()
    }

    suspend fun insert(newItem: Item): Long {
        return dao.insertItem(newItem)
    }

    suspend fun delete(item: Item) {
        dao.deleteItem(item)
    }

    companion object {
        @Volatile
        private var instance: Repository? = null
        fun getInstance(
            apiService: ApiService,
            dao: ItemDao
        ): Repository = instance ?: synchronized(this) {
            instance ?: Repository(apiService, dao)
        }.also { instance = it }
    }
}