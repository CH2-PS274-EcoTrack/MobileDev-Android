package com.capstone.ecotracker.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.capstone.ecotracker.data.Repository
import com.capstone.ecotracker.ui.activity.ActivityViewModel
import com.capstone.ecotracker.ui.add.AddViewModel
import com.capstone.ecotracker.ui.classification.ClassificationViewModel
import com.capstone.ecotracker.utils.Injection.provideRepository

class ViewModelFactory(
    private val repository: Repository
): ViewModelProvider.Factory {

    companion object {
        @Volatile
        private var instance: ViewModelFactory? = null

        fun getInstance(context: Context): ViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: ViewModelFactory(
                    provideRepository(context)
                )
            }
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        when {
            modelClass.isAssignableFrom(ActivityViewModel::class.java) -> {
                ActivityViewModel(repository) as T
            }
            modelClass.isAssignableFrom(AddViewModel::class.java) -> {
                AddViewModel(repository) as T
            }
            modelClass.isAssignableFrom(ClassificationViewModel::class.java) -> {
                ClassificationViewModel(repository) as T
            }
            else -> throw Throwable("Unknown ViewModel class: " + modelClass.name)
        }
}