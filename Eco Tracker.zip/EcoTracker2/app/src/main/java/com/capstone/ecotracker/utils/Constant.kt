package com.capstone.ecotracker.utils

const val MAX_ENGINE_SIZE = 3.5
const val MIN_ENGINE_SIZE = 1.0
const val MAX_FUEL_CONSUMPTION = 20.7
const val MIN_FUEL_CONSUMPTION = 4.3
const val MAX_CYLINDERS = 6.0
const val MIN_CYLINDERS = 3.0
const val MAX_EMISSION = 380.0
const val MIN_EMISSION = 88.0