package com.capstone.ecotracker.data.response

import com.google.gson.annotations.SerializedName

data class ImageResponse(
    @field:SerializedName("data")
    val data: ImageData? = null,

    @field:SerializedName("message")
    val message: String? = null
)

data class ImageData (
    @field:SerializedName("className")
    val className: String? = null,

    @field:SerializedName("confidenceScore")
    val confidenceScore: Double? = null
)