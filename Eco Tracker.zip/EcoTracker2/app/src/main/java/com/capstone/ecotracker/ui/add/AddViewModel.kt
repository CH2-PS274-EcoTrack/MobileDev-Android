package com.capstone.ecotracker.ui.add

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.capstone.ecotracker.data.Repository
import com.capstone.ecotracker.data.localDatabase.Item
import com.capstone.ecotracker.data.response.UploadInputResponse
import kotlinx.coroutines.launch
import com.capstone.ecotracker.data.Result
import com.capstone.ecotracker.data.response.ForecastResponse


class AddViewModel(private val repository: Repository): ViewModel() {

    private val _uploadInputResponse = MediatorLiveData<Result<UploadInputResponse>>()
    val uploadInputResponse: LiveData<Result<UploadInputResponse>> = _uploadInputResponse

//    fun addData(item: Item) = viewModelScope.launch {
//        repository.insert(item)
//    }

    fun uploadUserInput(
        cylinder: Double,
        engineSize: Double,
        fuelConsumption: Double
    ) {
        val liveData = repository.uploadUserInput(cylinder, engineSize, fuelConsumption)
        _uploadInputResponse.addSource(liveData) { result ->
            _uploadInputResponse.value = result
        }
    }

    fun getEmission(): LiveData<ForecastResponse> {
        return repository.getForecastResult()
    }
}