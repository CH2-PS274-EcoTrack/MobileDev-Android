package com.capstone.ecotracker.ui.add

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import androidx.lifecycle.ViewModelProvider
import com.capstone.ecotracker.data.Result
import com.capstone.ecotracker.MainActivity
import com.capstone.ecotracker.R
import com.capstone.ecotracker.databinding.ActivityAddBinding
import com.capstone.ecotracker.databinding.ResultDialogBinding
import com.capstone.ecotracker.ui.ViewModelFactory
import com.capstone.ecotracker.utils.DatePickerFragment
import com.capstone.ecotracker.utils.MAX_CYLINDERS
import com.capstone.ecotracker.utils.MAX_ENGINE_SIZE
import com.capstone.ecotracker.utils.MAX_FUEL_CONSUMPTION
import com.capstone.ecotracker.utils.MIN_CYLINDERS
import com.capstone.ecotracker.utils.MIN_ENGINE_SIZE
import com.capstone.ecotracker.utils.MIN_FUEL_CONSUMPTION
import com.capstone.ecotracker.utils.Utils.scale
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddActivity : AppCompatActivity(), DatePickerFragment.DialogDateListener {
    private lateinit var binding: ActivityAddBinding
    private lateinit var resultBinding: ResultDialogBinding
    private lateinit var viewModel: AddViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory) [AddViewModel::class.java]

        viewModel.uploadInputResponse.observe(this) {
            when (it) {
                is Result.Success -> {
                    Log.d("data", it.data.toString())
                }
                is Result.Error -> {

                } else -> {}
            }
        }

        val vehicleType = resources.getStringArray(R.array.vehicle_options)
        val spinner = binding.spinner
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, vehicleType)
        spinner.adapter = adapter

        binding.btnBack.setOnClickListener{
            val intent = Intent(this@AddActivity,MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvChooseDate.setOnClickListener{
            showDatePicker()
        }

        binding.btnSave.setOnClickListener {
            uploadUserInput()
            showResultDialog()
        }
    }

    private fun uploadUserInput() {
        val engineSize = binding.inputEngine.text.toString().toDouble()
        val fuel = binding.inputFuel.text.toString().toDouble()
        val cylinder = binding.inputCylinder.text.toString().toDouble()

        val xScaledEngine = scale(engineSize, MAX_ENGINE_SIZE, MIN_ENGINE_SIZE)
        val xScaledFuel = scale(fuel, MIN_FUEL_CONSUMPTION, MAX_FUEL_CONSUMPTION)
        val xScaledCylinder = scale(cylinder, MIN_CYLINDERS, MAX_CYLINDERS)

        viewModel.uploadUserInput(xScaledCylinder, xScaledEngine, xScaledFuel)
    }
    private fun showResultDialog() {
        val dialog = Dialog(this)

        resultBinding = ResultDialogBinding.inflate(layoutInflater)
        dialog.setContentView(resultBinding.root)

        dialog.show()
    }

    fun showDatePicker() {
        val dialogFragment = DatePickerFragment()
        dialogFragment.show(supportFragmentManager, "datePicker")
    }

    override fun onDialogDateSet(tag: String?, year: Int, month: Int, dayOfMonth: Int) {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, dayOfMonth)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        binding.tvChooseDate.text = dateFormat.format(calendar.time)

//        dueDateMillis = calendar.timeInMillis
    }
}