package com.capstone.ecotracker.ui.classification

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.capstone.ecotracker.MainActivity
import com.capstone.ecotracker.databinding.ActivityClassificationBinding
import com.capstone.ecotracker.databinding.ResultClassificationDialogBinding
import com.capstone.ecotracker.ui.ViewModelFactory
import com.capstone.ecotracker.utils.getImageUri
import com.capstone.ecotracker.utils.reduceFileImage
import com.capstone.ecotracker.utils.uriToFile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody

class ClassificationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityClassificationBinding
    private lateinit var classificationBinding: ResultClassificationDialogBinding
    private lateinit var viewModel: ClassificationViewModel
    private var currentImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityClassificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory) [ClassificationViewModel::class.java]

        binding.btnGallery.setOnClickListener{
            startGallery()
        }
        binding.btnCamera.setOnClickListener {
            requestCameraPermission()
        }
        binding.btnUpload.setOnClickListener {
            uploadImage()
        }
        binding.btnResult.setOnClickListener {
            showClassificationDialog()
        }
        binding.btnBack.setOnClickListener {
            val intent = Intent(this@ClassificationActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun showClassificationDialog() {
        val dialog = Dialog(this)

        classificationBinding = ResultClassificationDialogBinding.inflate(layoutInflater)
        dialog.setContentView(classificationBinding.root)

        dialog.show()
    }

    private fun startGallery() {
        launcherGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            currentImageUri = uri
            showImage()
        }
    }

    private fun startCamera() {
        currentImageUri = getImageUri(this)
        launcherIntentCamera.launch(currentImageUri)
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { isSuccess ->
        if (isSuccess) {
            showImage()
        }
    }

    private fun showImage() {
        currentImageUri?.let {
            binding.ivImage.setImageURI(it)
        }
    }

    private fun uploadImage() {
        currentImageUri?.let { uri ->
            val imageFile = uriToFile(uri, this).reduceFileImage()

            val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
            val multipartBody = MultipartBody.Part.createFormData(
                "photo",
                imageFile.name,
                requestImageFile
            )
            viewModel.uploadImage(multipartBody)
        }
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            val permissions = arrayOf(Manifest.permission.CAMERA)
            ActivityCompat.requestPermissions(this, permissions, CAMERA_PERMISSION_REQUEST_CODE)
        } else {
            startCamera()
        }
    }

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100

    }
}