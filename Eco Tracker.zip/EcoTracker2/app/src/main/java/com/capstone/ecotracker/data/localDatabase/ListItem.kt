package com.capstone.ecotracker.data.localDatabase

import java.util.Date

object ListItem {
    val ListItem = mutableListOf<Item>(
        Item(
            1,
            "mobil",
            "60.05 kg CO2",
        ),
        Item(
            2,
            "bus",
            "120.4 kg CO2",
        ),
        Item(
            3,
            "motor",
            "44.12 kg CO2",
        ),
        Item(
            4,
            "bus",
            "70.47 kg CO2",
        ),
        Item(
            5,
            "mobil",
            "57.21 kg CO2",
        ),
        Item(
            6,
            "motor",
            "38.87 kg CO2",
        )
    )
}