package com.capstone.ecotracker.data.localDatabase

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "item")
data class Item(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Int = 0,

    @ColumnInfo(name = "vehicleType")
    val vehicleType: String,

    @ColumnInfo(name = "emission")
    val emission: String,
)
