package com.capstone.ecotracker.utils

object Utils {
    fun scale(x: Double, xMin: Double, xMax: Double): Double {
        return (x - xMin) / (xMax - xMin)
    }

}