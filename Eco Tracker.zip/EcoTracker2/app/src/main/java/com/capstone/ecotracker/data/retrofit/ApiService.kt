package com.capstone.ecotracker.data.retrofit

import com.capstone.ecotracker.data.response.ForecastResponse
import com.capstone.ecotracker.data.response.ImageResponse
import com.capstone.ecotracker.data.response.UploadImageResponse
import com.capstone.ecotracker.data.response.UploadInputResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path

interface ApiService {
    @Multipart
    @POST("prediciton/image")
    suspend fun uploadImage(
        @Part images: MultipartBody.Part
    ): UploadImageResponse

    @GET("prediciton/image")
    suspend fun getImage(): ImageResponse

    @GET("prediciton/forecast")
    suspend fun getForecast(): ForecastResponse

    @POST("prediction/forecast")
    suspend fun uploadUserInput(
        @Part("cylinder") cylinder: Double,
        @Part("engineSize") engineSize: Double,
        @Part("fuelConsumption") fuelConsumption: Double
    ): UploadInputResponse
}