package com.capstone.ecotracker.ui.signup

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.capstone.ecotracker.MainActivity
import com.capstone.ecotracker.R
import com.capstone.ecotracker.databinding.ActivitySignUpBinding
import com.capstone.ecotracker.ui.login.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        auth = FirebaseAuth.getInstance()

        binding.btnRegister.setOnClickListener {
            registerUser()
        }
        binding.btnBack.setOnClickListener{
            val intent = Intent(this@SignUpActivity,LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun registerUser() {
        val name = binding.edName.text.toString()
        val inputConfirmPassword = binding.edConfirmPassword
        val email = binding.edEmail.text.toString().trim()
        val password = binding.edPassword.text.toString().trim()
        val confirmPassword = binding.edConfirmPassword.text.toString().trim()

        if (password != confirmPassword) {
            inputConfirmPassword.error = (getString(R.string.invalid_confirmPassword))
            Handler(Looper.getMainLooper()).postDelayed({
                inputConfirmPassword.error = null
            }, 2000)
        } else {
            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this) {
                if (it.isSuccessful) {
                    Toast.makeText(this, "Registrasi Berhasil", Toast.LENGTH_SHORT).show()
                    val firebaseUser = auth.currentUser!!
                    val profileUpdates = userProfileChangeRequest {
                        displayName = name
                        //photo jgn lupa diganti
                        photoUri = Uri.parse("https://picsum.photos/800")
                    }
                    firebaseUser.updateProfile(profileUpdates)
                    val intent = Intent(this@SignUpActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Registrasi Gagal", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}