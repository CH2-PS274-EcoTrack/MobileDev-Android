package com.capstone.ecotracker.ui.classification

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import com.capstone.ecotracker.data.Repository
import com.capstone.ecotracker.data.Result
import com.capstone.ecotracker.data.response.ImageResponse
import com.capstone.ecotracker.data.response.UploadImageResponse
import okhttp3.MultipartBody

class ClassificationViewModel(private val repository: Repository): ViewModel() {
    private val _uploadImageResponse = MediatorLiveData<Result<UploadImageResponse>>()
    val uploadInputResponse: LiveData<Result<UploadImageResponse>> = _uploadImageResponse

    fun uploadImage(
        image: MultipartBody.Part
    ){
        val liveData = repository.uploadImage(image)
        _uploadImageResponse.addSource(liveData) { result ->
            _uploadImageResponse.value = result
        }
    }

    fun getClassification(): LiveData<ImageResponse> {
        return repository.getImageResult()
    }
}