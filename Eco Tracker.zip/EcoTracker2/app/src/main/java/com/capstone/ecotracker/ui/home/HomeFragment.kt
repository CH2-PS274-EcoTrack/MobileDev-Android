package com.capstone.ecotracker.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.capstone.ecotracker.databinding.FragmentHomeBinding
import com.capstone.ecotracker.ui.add.AddActivity
import com.capstone.ecotracker.ui.classification.ClassificationActivity

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding

    // This property is only valid between onCreateView and
    // onDestroyView.


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val progressBar = binding.circularPb
        progressBar.progress = 30

        binding.btnCamera.setOnClickListener{
            val intent = Intent(binding.root.context, ClassificationActivity::class.java)
            startActivity(intent)
            activity?.finish()
        }

        binding.fabAdd.setOnClickListener{
            val intent = Intent(binding.root.context, AddActivity::class.java)
            startActivity(intent)
            activity?.finish()
        }

        return root
    }
}