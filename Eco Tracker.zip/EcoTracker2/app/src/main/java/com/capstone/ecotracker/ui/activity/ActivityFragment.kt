package com.capstone.ecotracker.ui.activity

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.capstone.ecotracker.data.localDatabase.ListItem
import com.capstone.ecotracker.databinding.FragmentActivityBinding

class ActivityFragment : Fragment() {

    private lateinit var binding: FragmentActivityBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentActivityBinding.inflate(inflater, container, false)
        val root: View = binding.root


        val layoutManager = LinearLayoutManager(binding.root.context)
        var recycler = binding.rvActivityUser
        recycler.layoutManager = layoutManager
        val adapter = EmissionAdapter()
        adapter.submitList(ListItem.ListItem)
        recycler.adapter = adapter
        return root
    }
}