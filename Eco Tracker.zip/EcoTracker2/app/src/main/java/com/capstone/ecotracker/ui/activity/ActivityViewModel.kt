package com.capstone.ecotracker.ui.activity

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.capstone.ecotracker.data.Repository
import com.capstone.ecotracker.data.localDatabase.Item

class ActivityViewModel(private val repository: Repository) : ViewModel() {

    private val _item = MutableLiveData<List<Item>>()
    val item: LiveData<List<Item>> = _item

}