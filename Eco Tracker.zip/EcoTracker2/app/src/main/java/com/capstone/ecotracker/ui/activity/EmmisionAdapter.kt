package com.capstone.ecotracker.ui.activity

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.capstone.ecotracker.R
import com.capstone.ecotracker.data.localDatabase.Item
import com.capstone.ecotracker.databinding.RowItemEmissionBinding

class EmissionAdapter : ListAdapter<Item, EmissionAdapter.MyViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = RowItemEmissionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = getItem(position) as Item
        holder.bind(item)
    }

    class MyViewHolder(private val binding: RowItemEmissionBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Item) {
            binding.tvVehicleType.text = item.vehicleType
            binding.tvVehicleEmission.text = item.emission
            when (item.vehicleType) {
                "motor" -> binding.ivVehicle.setImageResource(R.drawable.ic_motor)
                "mobil" -> binding.ivVehicle.setImageResource(R.drawable.ic_car)
                "bus" -> binding.ivVehicle.setImageResource(R.drawable.ic_bus)
                "kereta" -> binding.ivVehicle.setImageResource(R.drawable.ic_train)
            }
        }
    }


    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Item>() {
            override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean {
                return oldItem.emission == newItem.emission
            }

            override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean {
                return oldItem == newItem
            }
        }
        const val PARCEL_NAME = "data"
    }
}