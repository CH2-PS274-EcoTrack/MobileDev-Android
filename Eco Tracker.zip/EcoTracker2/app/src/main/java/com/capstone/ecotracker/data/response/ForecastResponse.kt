package com.capstone.ecotracker.data.response

import com.google.gson.annotations.SerializedName

data class ForecastResponse (
    @field:SerializedName("data")
    val data: ForecastData? = null,

    @field:SerializedName("message")
    val message: String? = null
)

data class ForecastData (
    @field:SerializedName("co2Forecast")
    val co2Forecast: Double? = null
)